<?php $__env->startSection('title', 'All in One Place'); ?>
<?php $__env->startSection('content'); ?>

      <!-- page content -->


      <!DOCTYPE html>
      <html lang="en">

      <head>
        <meta name="author" content="Anthony Mutisya | https://www.linkedin.com/profile/view?id=239476959">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- Meta, title, CSS, favicons, etc. -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Vodacom Sim Registration reporting">
        <meta name="keywords" content="Vodacom Sim Registration Dashboard">

        <title>SixxmReg Dashboard</title>

        <!-- Bootstrap core CSS -->
        <link href="http://vodacom.registersim.com/assets/dashboard/template_files/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" media="all" href="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/daterangepicker-bs3.css" />

        <link rel="stylesheet" href="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/colorbox.css" />
        <link href="http://vodacom.registersim.com/assets/dashboard/css/font/css/font-awesome.min.css" rel="stylesheet">

        <script src="http://vodacom.registersim.com/assets/dashboard/template_files/jquery.min.js"></script>
        <script src="http://vodacom.registersim.com/assets/dashboard/template_files/bootstrap.min.js"></script>
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

      </head>

      <body data-twttr-rendered="true">
        <style>
          body {
            background: #fff;
            color: #6F6F6F
          }

          @media (min-width: 1200px) {
            .container {
              width: 1250px !important;
            }
          }

          a {
            color: #75787B;
          }

          .top_menu {
            margin-top: 6px
          }

          .page_logo {
            width: 25%;
            float: left;
            height: 75px;
            font-size: 25px;
          }

          .page_nav {
            width: 75%;
            float: left
          }

          .report_title {
            font-size: 20px;
            color: #75787B;
            font-weight: bold;
            border-bottom: 2px solid #B4B4B4;
            padding-bottom: 5px;
          }

          .report_title:hover {
            color: #e00000;
            border-bottom: 2px solid #7c7c7c;
          }

          @media (min-width: 992px) {
            .col-md-4 {
              width: 33%;
            }
            .col-md-8 {
              width: 65%
            }
          }

          .nav-tabs > li > a {
            border: 0;
          }

          .nav-tabs {
            border: 0;
            margin-top: 22px
          }

          .nav-tabs > li.active > a,
          .nav-tabs > li.active > a:hover,
          .nav-tabs > li.active > a:focus {
            color: #FFF;
            cursor: default;
            background-color: transparent;
            border: 0px solid #ddd;
            border-bottom-color: transparent;
          }

          .nav > li > a:hover,
          .nav > li > a:focus {
            text-decoration: none;
            background-color: rgba(0, 0, 0, 0.13);
            border: 0;
            color: #C2C2C2;
          }

          .daterangepicker table {
            width: 100%;
            margin: 0;
            color: #70757E;
          }

          .nav > li > a:hover,
          .nav > li > a:focus {
            text-decoration: none;
            background-color: rgba(0, 0, 0, 0);
            border: 0;
            color: #C2C2C2;
          }

          .single_block {
            overflow: hidden !important
          }

          #main-map canvas {
            margin-top: 2px;
          }

          .map.anto {
            zoom: 0.9%;
            zoom: 0.87;
            -ms-zoom: 0.9;
            -webkit-zoom: 0.9;
            -moz-transform: scale(0.9, 0.9);
            -moz-transform-origin: left center;
          }

          #map-tooltip {
            position: absolute;
            background: #f2f2f2;
            border: solid 2px #bababa;
            margin-left: 5px;
            margin-top: 0px;
            padding: 7px;
            border-radius: 5px;
            -moz-border-radius: 5px;
            -webkit-border-radius: 5px;
            z-index: 1000;
          }

          .white {
            background: #fff !important
          }

          .btn-primary {
            color: #fff;
            background-color: #9D9D9D;
            border-color: #9D9D9D;
          }

          .btn-primary:hover,
          .btn-primary:focus,
          .btn-primary:active,
          .btn-primary.active,
          .open > .dropdown-toggle.btn-primary {
            color: #fff;
            background-color: #797878;
            border-color: #797878;
          }
        </style>

        <!DOCTYPE html>
        <html lang="en">

        <head>
          <meta name="author" content="Anthony Mutisya | https://www.linkedin.com/profile/view?id=239476959">


          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
          <!-- Meta, title, CSS, favicons, etc. -->
          <meta charset="utf-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <meta name="description" content="Tigo Sim Registration reporting">
          <meta name="keywords" content="Tigo Sim Registration Dashboard">

          <title>SimReg Dashboard</title>
          <!-- Bootstrap core CSS -->
          <link href="http://tigo.registersim.com/assets/dashboard/template_files/bootstrap.css" rel="stylesheet">
          <link rel="stylesheet" type="text/css" media="all" href="http://tigo.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/daterangepicker-bs3.css" />

          <link rel="stylesheet" href="http://tigo.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/colorbox.css" />
          <link href="http://tigo.registersim.com/assets/dashboard/css/font/css/font-awesome.min.css" rel="stylesheet">
          <script src="http://tigo.registersim.com/assets/dashboard/template_files/jquery.min.js"></script>
          <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
          <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        </head>

        <body data-twttr-rendered="true">
          <style>
            body {
              background: rgb(80, 96, 186);
              color: #fff
            }

            @media (min-width: 1200px) {
              .container {
                width: 1250px !important;
              }
            }

            a {
              color: rgb(255, 172, 42);
            }

            .top_menu {
              margin-top: 6px
            }

            .page_logo {
              width: 25%;
              float: left;
              height: 75px;
              font-size: 25px;
            }

            .page_nav {
              width: 75%;
              float: left
            }

            .report_title {
              font-size: 20px;
              color: #F4F8FC;
              font-weight: bold;
              border-bottom: 2px solid #B4B4B4;
              padding-bottom: 5px;
            }

            .report_title:hover {
              color: rgb(255, 172, 42);
              border-bottom: 2px solid #7c7c7c;
            }

            @media (min-width: 992px) {
              .col-md-4 {
                width: 33%;
              }
              .col-md-8 {
                width: 65%
              }
            }

            .nav-tabs > li > a {
              border: 0;
            }

            .nav-tabs {
              border: 0;
              margin-top: 22px
            }

            .nav-tabs > li.active > a,
            .nav-tabs > li.active > a:hover,
            .nav-tabs > li.active > a:focus {
              color: #FFF;
              cursor: default;
              background-color: transparent;
              border: 0px solid #ddd;
              border-bottom-color: transparent;
            }

            .nav > li > a:hover,
            .nav > li > a:focus {
              text-decoration: none;
              background-color: rgba(0, 0, 0, 0.13);
              border: 0;
              color: #C2C2C2;
            }

            .daterangepicker table {
              width: 100%;
              margin: 0;
              color: #70757E;
            }

            .nav > li > a:hover,
            .nav > li > a:focus {
              text-decoration: none;
              background-color: rgba(0, 0, 0, 0);
              border: 0;
              color: #C2C2C2;
            }

            .single_block {
              overflow: hidden !important
            }

            #main-map canvas {
              margin-top: 2px;
            }

            .map.anto {
              zoom: 0.9%;
              zoom: 0.9;
              -ms-zoom: 0.9;
              -webkit-zoom: 0.9;
              -moz-transform: scale(0.9, 0.9);
              -moz-transform-origin: left center;
            }

            #map-tooltip {
              position: absolute;
              background: #f2f2f2;
              border: solid 2px ##bababa;
              margin-left: 5px;
              margin-top: 0px;
              padding: 7px;
              border-radius: 5px;
              -moz-border-radius: 5px;
              -webkit-border-radius: 5px;
              z-index: 1000;
            }
          </style>
          <style type="text/css">
            #map-container {
              padding: 6px;
              border-width: 1px;
              border-style: solid;
              border-color: #ccc #ccc #999 #ccc;
              -webkit-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
              -moz-box-shadow: rgba(64, 64, 64, 0.5) 0 2px 5px;
              box-shadow: rgba(64, 64, 64, 0.1) 0 2px 5px;
              width: 100%;
            }

            body {
              background: white !important;
              color: #585757 !important;
            }

            #map {
              width: 100%;
              height: 100%;
            }
          </style>
          <script src="http://www.google.com/jsapi"></script>
          <script type="text/javascript">
            var script = '<script type="text/javascript" src="http://tigo.registersim.com/assets/<?php echo e(url('/')); ?>/gentella-js/src/markerclusterer';
            if (document.location.search.indexOf('packed') !== -1) {
              script += '_packed';
            }
            if (document.location.search.indexOf('compiled') !== -1) {
              script += '_compiled';
            }
            script += '.js"><' + '/script>';
            document.write(script);
          </script>
          <script type="text/javascript">
            google.load('maps', '3', {
              other_params: 'sensor=false'
            });
            google.setOnLoadCallback(initialize);

            function initialize() {
              var data = {
                "count": 5,
                "photos": [{
                  "longitude": "39.2742524",
                  "latitude": "-6.7859093",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-11-26 17:02:18",
                  "msisdn": "255754649464",
                  "registrant": "Tester Teat"
                }, {
                  "longitude": "39.2742393",
                  "latitude": "-6.7859373",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-11-26 17:09:33",
                  "msisdn": "255759121175",
                  "registrant": "Anton Mutisya"
                }, {
                  "longitude": "39.2742669",
                  "latitude": "-6.7859201",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-11-26 17:23:27",
                  "msisdn": "255754664646",
                  "registrant": "Anthony Mutisya"
                }, {
                  "longitude": "39.2742574",
                  "latitude": "-6.7859192",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-11-26 17:39:28",
                  "msisdn": "255759156005",
                  "registrant": "Anthony Kimuyu"
                }, {
                  "longitude": "33.4450826",
                  "latitude": "-8.8946264",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-11-27 08:57:10",
                  "msisdn": "255769076177",
                  "registrant": "Jerry January"
                }, {
                  "longitude": "33.4450826",
                  "latitude": "-8.8946264",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-11-27 09:29:58",
                  "msisdn": "255755968449",
                  "registrant": "Irene Mkocha"
                }, {
                  "longitude": "33.4450826",
                  "latitude": "-8.8946264",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-11-27 10:07:15",
                  "msisdn": "255754418578",
                  "registrant": "Andreas Koall"
                }, {
                  "longitude": "33.4453114",
                  "latitude": "-8.8975525",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-11-27 11:50:12",
                  "msisdn": "255754424478",
                  "registrant": "Lelo Denis"
                }, {
                  "longitude": "39.2497688",
                  "latitude": "-6.7785672",
                  "created_by": "MFS Arusha (12)",
                  "created_date": "2014-11-28 16:07:07",
                  "msisdn": "255759156669",
                  "registrant": "Joyce Banda"
                }, {
                  "longitude": "39.2499913",
                  "latitude": "-6.7782498",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 16:43:10",
                  "msisdn": "255767787878",
                  "registrant": "Waziri Seif"
                }, {
                  "longitude": "39.2499313",
                  "latitude": "-6.7783394",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 16:47:03",
                  "msisdn": "255754665865",
                  "registrant": "Dded Dhdb"
                }, {
                  "longitude": "39.2499022",
                  "latitude": "-6.7782986",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 16:53:14",
                  "msisdn": "255756554587",
                  "registrant": "Bvdhh Bcx"
                }, {
                  "longitude": "39.2499574",
                  "latitude": "-6.7781802",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:15:21",
                  "msisdn": "255755825146",
                  "registrant": "Nxnx Snsh"
                }, {
                  "longitude": "39.2499574",
                  "latitude": "-6.7781802",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:16:17",
                  "msisdn": "255756585247",
                  "registrant": "Fvkk Gy"
                }, {
                  "longitude": "39.2499574",
                  "latitude": "-6.7781802",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:19:11",
                  "msisdn": "255759156666",
                  "registrant": "Dndnx Jdjd"
                }, {
                  "longitude": "39.2498256",
                  "latitude": "-6.7784916",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:30:14",
                  "msisdn": "255753607777",
                  "registrant": "Pele Papa"
                }, {
                  "longitude": "39.2498256",
                  "latitude": "-6.7784916",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:33:21",
                  "msisdn": "255767824667",
                  "registrant": "Jdjd Ejsjsj"
                }, {
                  "longitude": "39.2489626",
                  "latitude": "-6.7797491",
                  "created_by": "MFS Mulimu FS",
                  "created_date": "2014-11-28 17:38:05",
                  "msisdn": "255756215030",
                  "registrant": "Pipi Pipi"
                }, {
                  "longitude": "36.6806413",
                  "latitude": "-3.3751969",
                  "created_by": "MFS Vodashop Karatu",
                  "created_date": "2014-12-01 13:12:50",
                  "msisdn": "255754555444",
                  "registrant": "Bakari Fungo"
                }, {
                  "longitude": "39.2742455",
                  "latitude": "-6.7859107",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-12-01 17:33:17",
                  "msisdn": "255756884665",
                  "registrant": "Davidmchokozi Test"
                }, {
                  "longitude": "39.2742679",
                  "latitude": "-6.7859206",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-12-01 17:48:59",
                  "msisdn": "255756945464",
                  "registrant": "Kinani Test"
                }, {
                  "longitude": "39.2742544",
                  "latitude": "-6.7859181",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-12-01 17:55:01",
                  "msisdn": "255756484884",
                  "registrant": "Tonnitto Test"
                }, {
                  "longitude": "39.2742566",
                  "latitude": "-6.785915",
                  "created_by": "AIM Testing5",
                  "created_date": "2014-12-01 18:03:03",
                  "msisdn": "255756948441",
                  "registrant": "Mutisyakimaniii Hhdhd"
                }, {
                  "longitude": "35.6448253",
                  "latitude": "-10.677705",
                  "created_by": "MFS Vodashop Songea 2",
                  "created_date": "2014-12-02 07:42:23",
                  "msisdn": "255766657080",
                  "registrant": "Teofrida Komba"
                }, {
                  "longitude": "39.24825666666666",
                  "latitude": "-6.832218333333333",
                  "created_by": "MFS Vodashop Buguruni 2",
                  "created_date": "2014-12-02 15:25:59",
                  "msisdn": "255752999941",
                  "registrant": "James Mboya"
                }, {
                  "longitude": "35.2975287",
                  "latitude": "-8.2997532",
                  "created_by": "MFS Vodashop Mafinga",
                  "created_date": "2014-12-02 15:46:30",
                  "msisdn": "255763893114",
                  "registrant": "Grac Mahenge"
                }, {
                  "longitude": "39.2203726",
                  "latitude": "-6.7726398",
                  "created_by": "MFS Vodashop Mlimani City 2",
                  "created_date": "2014-12-02 15:50:28",
                  "msisdn": "255757725092",
                  "registrant": "Deogratius Kashinde"
                }, {
                  "longitude": "32.9423018",
                  "latitude": "-9.1075252",
                  "created_by": "MFS Vodashop Mbozi",
                  "created_date": "2014-12-02 15:59:59",
                  "msisdn": "255769129833",
                  "registrant": "Jackson Sailas"
                }, {
                  "longitude": "34.8244732",
                  "latitude": "-8.8513982",
                  "created_by": "MFS Free Agent Makambako VS 9",
                  "created_date": "2014-12-02 16:13:54",
                  "msisdn": "255757206531",
                  "registrant": "Noel Segamba"
                }, {
                  "longitude": "39.2181694",
                  "latitude": "-6.7747356",
                  "created_by": "MFS Vodashop Mlimani City 2",
                  "created_date": "2014-12-02 16:20:57",
                  "msisdn": "255756896532",
                  "registrant": "Test Test"
                }, {
                  "longitude": "38.9875959",
                  "latitude": "-6.7833518",
                  "created_by": "MFS Vodashop Kibaha",
                  "created_date": "2014-12-02 16:29:29",
                  "msisdn": "255767420792",
                  "registrant": "Nickson Mkenda"
                }, {
                  "longitude": "32.8011976",
                  "latitude": "-5.0217228",
                  "created_by": "MFS Vodashop Tabora",
                  "created_date": "2014-12-02 16:57:55",
                  "msisdn": "255764222896",
                  "registrant": "Theresia Simon"
                }, {
                  "longitude": "35.6483504",
                  "latitude": "-10.6776036",
                  "created_by": "MFS Vodashop Mbinga",
                  "created_date": "2014-12-03 08:08:45",
                  "msisdn": "255762714504",
                  "registrant": "Prosper Mahay"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 08:45:09",
                  "msisdn": "255757106803",
                  "registrant": "Mafuru Boniphace"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 09:11:22",
                  "msisdn": "255764173870",
                  "registrant": "Reginald Matofali"
                }, {
                  "longitude": "33.4449818",
                  "latitude": "-8.8951975",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-12-03 09:31:47",
                  "msisdn": "255758006147",
                  "registrant": "nicodemus Malisa"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 09:33:51",
                  "msisdn": "255759210166",
                  "registrant": "Adelmarsi Kimaro"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 09:37:30",
                  "msisdn": "255757213372",
                  "registrant": "Ally Ally"
                }, {
                  "longitude": "35.6483504",
                  "latitude": "-10.6776036",
                  "created_by": "MFS Vodashop Mbinga",
                  "created_date": "2014-12-03 09:45:58",
                  "msisdn": "255757988611",
                  "registrant": "Mohamed Ally"
                }, {
                  "longitude": "36.6932663",
                  "latitude": "-3.3738081",
                  "created_by": "MFS FREE AGENT ARUSHA Abel  O. Melembuki ( 7)",
                  "created_date": "2014-12-03 09:48:58",
                  "msisdn": "255767624824",
                  "registrant": "Fabius Maluli"
                }, {
                  "longitude": "32.8993664",
                  "latitude": "-2.5182807",
                  "created_by": "MFS Vodashop Mwanza PPF",
                  "created_date": "2014-12-03 09:50:49",
                  "msisdn": "255757658660",
                  "registrant": "John Mlwilo"
                }, {
                  "longitude": "39.274575",
                  "latitude": "-6.766905000000001",
                  "created_by": "MFS Vodashop Oysterbay",
                  "created_date": "2014-12-03 09:57:34",
                  "msisdn": "255757608470",
                  "registrant": "BABU MAKINDA"
                }, {
                  "longitude": "33.4452871",
                  "latitude": "-8.8975492",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-12-03 10:02:42",
                  "msisdn": "255767501009",
                  "registrant": "Albert Samwel"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:07:18",
                  "msisdn": "255757725672",
                  "registrant": "Moses Dingmwipwapwa"
                }, {
                  "longitude": "36.6926228",
                  "latitude": "-3.3731712",
                  "created_by": "MFS FREE AGENT ARUSHA  Fabius Maluli (14)",
                  "created_date": "2014-12-03 10:08:55",
                  "msisdn": "255769353612",
                  "registrant": "John Gwarehhi"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:14:26",
                  "msisdn": "255756056586",
                  "registrant": "Ramadhani Feisal"
                }, {
                  "longitude": "33.4449818",
                  "latitude": "-8.8951975",
                  "created_by": "MFS Vodashop Mbeya Lupaway",
                  "created_date": "2014-12-03 10:16:54",
                  "msisdn": "255767457802",
                  "registrant": "Baraka Kyando"
                }, {
                  "longitude": "39.2725987",
                  "latitude": "-6.7525411",
                  "created_by": "MFS Vodashop Slipway",
                  "created_date": "2014-12-03 10:18:06",
                  "msisdn": "255757887179",
                  "registrant": "AYESHA MAWJI"
                }, {
                  "longitude": "32.8993664",
                  "latitude": "-2.5182807",
                  "created_by": "MFS Vodashop Mwanza PPF",
                  "created_date": "2014-12-03 10:19:22",
                  "msisdn": "255762810245",
                  "registrant": "Selya Abdallah"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:19:39",
                  "msisdn": "255762039999",
                  "registrant": "Xiang Zhang"
                }, {
                  "longitude": "36.6926228",
                  "latitude": "-3.3731712",
                  "created_by": "MFS FREE AGENT ARUSHA  Fabius Maluli (14)",
                  "created_date": "2014-12-03 10:21:01",
                  "msisdn": "255754508356",
                  "registrant": "David Ntandu"
                }, {
                  "longitude": "32.8993664",
                  "latitude": "-2.5182807",
                  "created_by": "MFS Vodashop Mwanza PPF",
                  "created_date": "2014-12-03 10:27:07",
                  "msisdn": "255764707029",
                  "registrant": "Jonepo Rweyongeza"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:28:02",
                  "msisdn": "255762629999",
                  "registrant": "Changcheng Yu"
                }, {
                  "longitude": "39.274548333333335",
                  "latitude": "-6.766913333333334",
                  "created_by": "MFS Vodashop Oysterbay",
                  "created_date": "2014-12-03 10:44:29",
                  "msisdn": "255757309574",
                  "registrant": "Aysha Johnson"
                }, {
                  "longitude": "32.8993664",
                  "latitude": "-2.5182807",
                  "created_by": "MFS Vodashop Mwanza PPF",
                  "created_date": "2014-12-03 10:44:45",
                  "msisdn": "255766828574",
                  "registrant": "Enos Kapai"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:45:21",
                  "msisdn": "255764169964",
                  "registrant": "Quibhisa Sagini"
                }, {
                  "longitude": "39.2862177",
                  "latitude": "-6.818356",
                  "created_by": "MFS Vodashop Samora",
                  "created_date": "2014-12-03 10:49:57",
                  "msisdn": "255756171587",
                  "registrant": "Peter Msuya"
                }, {
                  "longitude": "39.2749072",
                  "latitude": "-6.765965",
                  "created_by": "MFS Vodashop Oysterbay",
                  "created_date": "2014-12-03 10:52:27",
                  "msisdn": "255766437816",
                  "registrant": "RICHARD MBIDUKA"
                }, {
                  "longitude": "37.3431962",
                  "latitude": "-3.3484379",
                  "created_by": "MFS Vodashop Moshi",
                  "created_date": "2015-01-10 09:01:09",
                  "msisdn": "255756972562",
                  "registrant": "Paolo Ai"
                }]
              };

              var center = new google.maps.LatLng(-5.782901, 36.0790061); //-7.0849437,35.8401773);
              var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 6,
                scrollwheel: false,
                maxZoom: 15,
                minZoom: 6,
                center: center,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                styles: [{
                  "featureType": "landscape",
                  "elementType": "labels",
                  "stylers": [{
                    "visibility": "off"
                  }]
                }, {
                  "featureType": "transit",
                  "elementType": "labels",
                  "stylers": [{
                    "visibility": "off"
                  }]
                }, {
                  "featureType": "poi",
                  "elementType": "labels",
                  "stylers": [{
                    "visibility": "off"
                  }]
                }, {
                  "featureType": "water",
                  "elementType": "labels",
                  "stylers": [{
                    "visibility": "off"
                  }]
                }, {
                  "featureType": "road",
                  "elementType": "labels.icon",
                  "stylers": [{
                    "visibility": "off"
                  }]
                }, {
                  "stylers": [{
                    "hue": "#00aaff"
                  }, {
                    "saturation": -100
                  }, {
                    "gamma": 2.15
                  }, {
                    "lightness": 12
                  }]
                }, {
                  "featureType": "road",
                  "elementType": "labels.text.fill",
                  "stylers": [{
                    "visibility": "on"
                  }, {
                    "lightness": 24
                  }]
                }, {
                  "featureType": "road",
                  "elementType": "geometry",
                  "stylers": [{
                    "lightness": 57
                  }]
                }]
              });
              var infoWindow = new google.maps.InfoWindow();
              var markers = [];
              var html_array = [];
              for (var i = 0, dataPhoto; dataPhoto = data.photos[i]; i++) {
                //console.log(dataPhoto.latitude + " :" + dataPhoto.registrant );
                var latLng = new google.maps.LatLng(dataPhoto.latitude, dataPhoto.longitude);
                var marker = new google.maps.Marker({
                  position: latLng
                });
                var html = "<div class='infowin'><strong>" + dataPhoto.registrant + "</strong><hr>";
                html = html + "<p><strong>MSISDN: </strong>" + dataPhoto.msisdn + "</p>";
                html = html + "<p><strong>Date: </strong>" + dataPhoto.created_date + "</p>";
                html = html + "<p><strong>Agent: </strong>" + dataPhoto.created_by + "</p>";
                html_array.push(html);
                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                  return function() {
                    infoWindow.setContent(html_array[i]);
                    infoWindow.open(map, this);
                  }
                })(marker, i));
                //google.maps.event.addListener(marker, 'mouseout', function() {
                // infoWindow.close();
                //});
                markers.push(marker);
              }
              var markerCluster = new MarkerClusterer(map, markers);
            }
          </script>
          <div id="map-container" style="height:560px">
            <div id="map"></div>
          </div>




          <script src="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/jquery.masonry.min.js"></script>
          <script>
            $(function() {
              $('#report_blocks').masonry({
                // options
                itemSelector: '.single_block',
              });
            });
          </script>

          <script src="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/jquery.colorbox.js"></script>
          <script>
            $(document).ready(function() {
              $(".iframe").colorbox({
                iframe: true,
                width: "85%",
                height: "96%"
              });

              //Example of preserving a JavaScript event for inline calls.
              $("#click").click(function() {
                $('#click').css({
                  "background-color": "#f00",
                  "color": "#fff",
                  "cursor": "inherit"
                }).text("Open this window again and this message will still be here.");
                return false;
              });
            });
          </script>

          <script type="text/javascript" src="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/moment.min.js"></script>
          <script type="text/javascript" src="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/daterangepicker.js"></script>
          <script type="text/javascript">
            $(document).ready(function() {

              //var cb = function(start, end, label) {
              //    console.log(start.toISOString(), end.toISOString(), label);
              //    $('#reportrange span').html(start.format('ll') + ' - ' + end.format('ll'));
              //   //alert("Callback has fired: [" + start.format('MMMM D, YYYY') + " to " + end.format('MMMM D, YYYY') + ", label = " + label + "]");
              //}

              var cb = function(start, end, label) {
                //console.log(start.toISOString(), end.toISOString(), label);
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                window.location.replace("http://localhost/work/simreg_newvoda/index.php/dashboard/?from=" + start.format('YYYY-MM-DD') + "&to=" + end.format('YYYY-MM-DD'));
              }

              var optionSet1 = {
                startDate: moment().subtract(29, 'days'),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '03/30/2015',
                dateLimit: {
                  days: 100
                },
                showDropdowns: true,
                showWeekNumbers: true,
                timePicker: false,
                timePickerIncrement: 1,
                timePicker12Hour: true,
                ranges: {
                  'Today': [moment(), moment()],
                  'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                  'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                  'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                  'This Month': [moment().startOf('month'), moment().endOf('month')],
                  'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                opens: 'right',
                buttonClasses: ['btn btn-default'],
                applyClass: 'btn-small btn-primary',
                cancelClass: 'btn-small',
                format: 'MM/DD/YYYY',
                separator: ' to ',
                locale: {
                  applyLabel: 'Submit',
                  cancelLabel: 'Clear',
                  fromLabel: 'From',
                  toLabel: 'To',
                  customRangeLabel: 'Custom',
                  daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                  monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                  firstDay: 1
                }
              };

              var optionSet2 = {
                startDate: moment().subtract(7, 'days'),
                endDate: moment(),
                opens: 'right',
                ranges: {
                  'Today': [moment(), moment()],
                  'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                  'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                  'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                  'This Month': [moment().startOf('month'), moment().endOf('month')],
                  'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
              };

              $('#reportrange span').html('Date Filtering'); //moment().subtract(29, 'days').format('ll') + ' - ' + moment().format('ll')

              $('#reportrange').daterangepicker(optionSet1, cb);

              $('#reportrange').on('show.daterangepicker', function() {
                console.log("show event fired");
              });
              $('#reportrange').on('hide.daterangepicker', function() {
                console.log("hide event fired");
              });
              $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
                console.log("apply event fired, start/end dates are " + picker.startDate.format('MMMM D, YYYY') + " to " + picker.endDate.format('MMMM D, YYYY'));
              });
              $('#reportrange').on('cancel.daterangepicker', function(ev, picker) {
                console.log("cancel event fired");
              });

              $('#options1').click(function() {
                $('#reportrange').data('daterangepicker').setOptions(optionSet1, cb);
              });

              $('#options2').click(function() {
                $('#reportrange').data('daterangepicker').setOptions(optionSet2, cb);
              });

              $('#destroy').click(function() {
                $('#reportrange').data('daterangepicker').remove();
              });

            });
          </script>

          <script type="text/javascript" src="http://vodacom.registersim.com/assets/dashboard/<?php echo e(url('/')); ?>/gentella-js/highcharts.js"></script>



          <script type="text/javascript" data-rocketsrc="http://vodacom.registersim.com/assets/dashboard/maps/jquery.maphilight.min.js;" data-rocketoptimized="true"></script>
          <script type="text/javascript" src="http://vodacom.registersim.com/assets/dashboard/maps/jquery.maphilight.min.js"></script>
        </body>

        </html>
        <!-- /page content -->
    </div>

    <!-- footer content -->
  </div>

  <div id="custom_notifications" class="custom-notifications dsp_none">
    <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
    </ul>
    <div class="clearfix"></div>
    <div id="notif-group" class="tabbed_notifications"></div>
  </div>

  <script src="<?php echo e(url('/')); ?>/gentella-js/bootstrap.min.js"></script>

  <!-- chart js -->
  <script src="<?php echo e(url('/')); ?>/gentella-js/chartjs/chart.min.js"></script>
  <!-- bootstrap progress js -->
  <script src="<?php echo e(url('/')); ?>/gentella-js/progressbar/bootstrap-progressbar.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/gentella-js/nicescroll/jquery.nicescroll.min.js"></script>
  <!-- icheck -->
  <script src="<?php echo e(url('/')); ?>/gentella-js/icheck/icheck.min.js"></script>

  <script src="<?php echo e(url('/')); ?>/gentella-js/custom.js"></script>

  <!-- pace -->
  <script src="<?php echo e(url('/')); ?>/gentella-js/pace/pace.min.js"></script>

  <!-- /footer content -->
  </body>

  </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>